package com.edusphere.identity.config;
 
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
 
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
 
@Configuration
public class OpenAPIConfig {
 
    @Bean
    public OpenAPI customOpenAPI() {
 
        final String securitySchemeName = "bearerAuth";
 
        return new OpenAPI()
                .info(new Info()
                        .title("EduSphere Identity Service API")
                        .version("1.0")
                        .description("JWT Authentication APIs"))
                
                // ✅ ADD SECURITY REQUIREMENT
                .addSecurityItem(new SecurityRequirement().addList(securitySchemeName))
                
                // ✅ DEFINE JWT SCHEME
                .components(new Components()
                        .addSecuritySchemes(securitySchemeName,
                                new SecurityScheme()
                                        .name(securitySchemeName)
                                        .type(SecurityScheme.Type.HTTP)
                                        .scheme("bearer")
                                        .bearerFormat("JWT")));
    }
}